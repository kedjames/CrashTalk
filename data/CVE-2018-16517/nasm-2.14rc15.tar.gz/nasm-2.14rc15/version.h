#ifndef NASM_VERSION_H
#define NASM_VERSION_H
#define NASM_MAJOR_VER      2
#define NASM_MINOR_VER      13
#define NASM_SUBMINOR_VER   99
#define NASM_PATCHLEVEL_VER 105
#define NASM_VERSION_ID     0x020d6369
#define NASM_VER            "2.14rc15"
#endif /* NASM_VERSION_H */
