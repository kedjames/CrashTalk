make clean
make CFLAGS="-g -static -ggdb" CXXFLAGS="-g -static -ggdb"
