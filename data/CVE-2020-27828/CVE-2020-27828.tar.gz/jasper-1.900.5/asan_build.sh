CFLAGS='-g -fsanitize=address' CXXFLAGS='-g -fsanitize=address' ./configure
make clean all 
