CC=/playpen/AFL/afl-gcc CXX=/playpen/AFL/afl-g++ ./configure --disable-shared
make clean all
